
import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

export default function Home() {
  const [step, setStep] = useState("home");
  const [formData, setFormData] = useState({
    name: "",
    profession: "",
    city: "",
    contacts: "",
    education: "",
    experience: "",
    skills: "",
    languages: "",
    about: ""
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleGenerate = () => {
    setStep("result");
  };

  return (
    <div className="p-6 max-w-3xl mx-auto">
      {step === "home" && (
        <div className="space-y-6">
          <h1 className="text-3xl font-bold">Документы с AI</h1>
          <p className="text-muted-foreground">Создавай резюме и документы автоматически</p>
          <Button onClick={() => setStep("form")}>Попробовать</Button>
        </div>
      )}

      {step === "form" && (
        <div className="space-y-4">
          <h2 className="text-2xl font-semibold">Генерация резюме</h2>
          <Input placeholder="ФИО" name="name" onChange={handleChange} />
          <Input placeholder="Специальность" name="profession" onChange={handleChange} />
          <Input placeholder="Город" name="city" onChange={handleChange} />
          <Input placeholder="Контакты" name="contacts" onChange={handleChange} />
          <Textarea placeholder="Образование" name="education" onChange={handleChange} />
          <Textarea placeholder="Опыт работы" name="experience" onChange={handleChange} />
          <Textarea placeholder="Навыки" name="skills" onChange={handleChange} />
          <Textarea placeholder="Языки" name="languages" onChange={handleChange} />
          <Textarea placeholder="О себе / Цель" name="about" onChange={handleChange} />
          <Button onClick={handleGenerate}>Сгенерировать</Button>
        </div>
      )}

      {step === "result" && (
        <Card>
          <CardContent className="p-4 space-y-2">
            <h2 className="text-xl font-bold">Ваше резюме</h2>
            <p><strong>ФИО:</strong> {formData.name}</p>
            <p><strong>Профессия:</strong> {formData.profession}</p>
            <p><strong>Город:</strong> {formData.city}</p>
            <p><strong>Контакты:</strong> {formData.contacts}</p>
            <p><strong>Образование:</strong> {formData.education}</p>
            <p><strong>Опыт работы:</strong> {formData.experience}</p>
            <p><strong>Навыки:</strong> {formData.skills}</p>
            <p><strong>Языки:</strong> {formData.languages}</p>
            <p><strong>О себе:</strong> {formData.about}</p>
            <Button className="mt-4">Скачать PDF</Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
